--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6 (Debian 11.6-1.pgdg90+1)
-- Dumped by pg_dump version 12.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mlc;
--
-- Name: mlc; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mlc WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE mlc OWNER TO postgres;

\connect mlc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ad_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.ad_type AS ENUM (
    'BASIC',
    'EXTRA'
);


ALTER TYPE public.ad_type OWNER TO postgres;

--
-- Name: idea_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.idea_state AS ENUM (
    'IDEA',
    'PROPOSAL',
    'PROJECT'
);


ALTER TYPE public.idea_state OWNER TO postgres;

--
-- Name: user_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_type AS ENUM (
    'ADMIN',
    'MOD',
    'SEG_ADMIN',
    'SEG_MOD',
    'MUNICIPAL_SEG_ADMIN',
    'BUSINESS',
    'RESIDENTIAL',
    'MUNICIPAL',
    'WORKER',
    'ASSOCIATE',
    'DEVELOPER'
);


ALTER TYPE public.user_type OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: UserSegments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserSegments" (
    id text NOT NULL,
    user_id text NOT NULL,
    home_segment_id integer,
    work_segment_id integer,
    school_segment_id integer,
    home_sub_segment integer,
    work_sub_segment integer,
    school_sub_segment integer,
    home_segment_name text,
    work_segment_name text,
    school_segment_name text,
    home_sub_segment_name text,
    work_sub_segment_name text,
    school_sub_segment_name text,
    home_super_segment_id integer,
    home_super_segment_name text,
    work_super_segment_id integer,
    work_super_segment_name text,
    school_super_segment_id integer,
    school_super_segment_name text
);


ALTER TABLE public."UserSegments" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: advertisement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertisement (
    id integer NOT NULL,
    owner_id text NOT NULL,
    creat_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    advertisement_title text NOT NULL,
    advertisement_type public.ad_type DEFAULT 'BASIC'::public.ad_type NOT NULL,
    advertisement_duration timestamp(3) without time zone,
    advertisement_position text NOT NULL,
    advertisement_image_path text NOT NULL,
    advertisement_external_link text NOT NULL,
    published boolean DEFAULT false NOT NULL
);


ALTER TABLE public.advertisement OWNER TO postgres;

--
-- Name: advertisement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertisement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertisement_id_seq OWNER TO postgres;

--
-- Name: advertisement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertisement_id_seq OWNED BY public.advertisement.id;


--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_seq OWNER TO postgres;

--
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_id_seq OWNED BY public.category.id;


--
-- Name: idea; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idea (
    id integer NOT NULL,
    author_id text NOT NULL,
    category_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    community_impact text,
    nature_impact text,
    arts_impact text,
    energy_impact text,
    manufacturing_impact text,
    state public.idea_state DEFAULT 'IDEA'::public.idea_state NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    champion_id text,
    segment_id integer,
    sub_segment_id integer,
    "userType" text DEFAULT 'Resident'::text NOT NULL,
    image_path text,
    super_segment_id integer NOT NULL
);


ALTER TABLE public.idea OWNER TO postgres;

--
-- Name: idea_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idea_address (
    id integer NOT NULL,
    idea_id integer NOT NULL,
    street_address text,
    street_address_2 text,
    city text,
    country text,
    postal_code text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.idea_address OWNER TO postgres;

--
-- Name: idea_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.idea_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.idea_address_id_seq OWNER TO postgres;

--
-- Name: idea_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.idea_address_id_seq OWNED BY public.idea_address.id;


--
-- Name: idea_comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idea_comment (
    id integer NOT NULL,
    idea_id integer NOT NULL,
    author_id text NOT NULL,
    content text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_segment_id text NOT NULL,
    segment_id integer,
    super_segment_id integer,
    sub_segment_id integer
);


ALTER TABLE public.idea_comment OWNER TO postgres;

--
-- Name: idea_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.idea_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.idea_comment_id_seq OWNER TO postgres;

--
-- Name: idea_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.idea_comment_id_seq OWNED BY public.idea_comment.id;


--
-- Name: idea_geo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idea_geo (
    id integer NOT NULL,
    idea_id integer NOT NULL,
    lat numeric(65,30),
    lon numeric(65,30),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.idea_geo OWNER TO postgres;

--
-- Name: idea_geo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.idea_geo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.idea_geo_id_seq OWNER TO postgres;

--
-- Name: idea_geo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.idea_geo_id_seq OWNED BY public.idea_geo.id;


--
-- Name: idea_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.idea_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.idea_id_seq OWNER TO postgres;

--
-- Name: idea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.idea_id_seq OWNED BY public.idea.id;


--
-- Name: idea_rating; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idea_rating (
    id integer NOT NULL,
    idea_id integer NOT NULL,
    author_id text NOT NULL,
    rating integer DEFAULT 0 NOT NULL,
    rating_explanation text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.idea_rating OWNER TO postgres;

--
-- Name: idea_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.idea_rating_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.idea_rating_id_seq OWNER TO postgres;

--
-- Name: idea_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.idea_rating_id_seq OWNED BY public.idea_rating.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id integer NOT NULL,
    idea_id integer NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.project_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_id_seq OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: proposal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proposal (
    id integer NOT NULL,
    idea_id integer NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.proposal OWNER TO postgres;

--
-- Name: proposal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proposal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proposal_id_seq OWNER TO postgres;

--
-- Name: proposal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proposal_id_seq OWNED BY public.proposal.id;


--
-- Name: report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report (
    id integer NOT NULL,
    email text NOT NULL,
    description text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.report OWNER TO postgres;

--
-- Name: report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_id_seq OWNER TO postgres;

--
-- Name: report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_id_seq OWNED BY public.report.id;


--
-- Name: segment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.segment (
    seg_id integer NOT NULL,
    country text NOT NULL,
    province text NOT NULL,
    segment_name text NOT NULL,
    super_segment_name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    "superSegId" integer NOT NULL
);


ALTER TABLE public.segment OWNER TO postgres;

--
-- Name: segmentRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."segmentRequest" (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_id text NOT NULL,
    country text NOT NULL,
    province text NOT NULL,
    "segment name" text NOT NULL,
    "sub segment name" text
);


ALTER TABLE public."segmentRequest" OWNER TO postgres;

--
-- Name: segmentRequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."segmentRequest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."segmentRequest_id_seq" OWNER TO postgres;

--
-- Name: segmentRequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."segmentRequest_id_seq" OWNED BY public."segmentRequest".id;


--
-- Name: segment_seg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.segment_seg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.segment_seg_id_seq OWNER TO postgres;

--
-- Name: segment_seg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.segment_seg_id_seq OWNED BY public.segment.seg_id;


--
-- Name: sub_segment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_segment (
    id integer NOT NULL,
    seg_id integer NOT NULL,
    sub_segment_name text NOT NULL,
    lat numeric(65,30),
    lon numeric(65,30),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sub_segment OWNER TO postgres;

--
-- Name: sub_segment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sub_segment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sub_segment_id_seq OWNER TO postgres;

--
-- Name: sub_segment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sub_segment_id_seq OWNED BY public.sub_segment.id;


--
-- Name: super_segment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_segment (
    super_seg_id integer NOT NULL,
    name text NOT NULL,
    country text NOT NULL,
    province text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.super_segment OWNER TO postgres;

--
-- Name: super_segment_super_seg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.super_segment_super_seg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_segment_super_seg_id_seq OWNER TO postgres;

--
-- Name: super_segment_super_seg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.super_segment_super_seg_id_seq OWNED BY public.super_segment.super_seg_id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id text NOT NULL,
    user_type public.user_type DEFAULT 'RESIDENTIAL'::public.user_type NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    f_name text,
    l_name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "passCode" text,
    "imagePath" text,
    banned boolean DEFAULT false NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_address (
    id integer NOT NULL,
    user_id text NOT NULL,
    street_address text,
    street_address_2 text,
    city text,
    country text,
    postal_code text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_address OWNER TO postgres;

--
-- Name: user_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_address_id_seq OWNER TO postgres;

--
-- Name: user_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_address_id_seq OWNED BY public.user_address.id;


--
-- Name: user_comment_dislikes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_comment_dislikes (
    id integer NOT NULL,
    idea_comment_id integer,
    author_id text
);


ALTER TABLE public.user_comment_dislikes OWNER TO postgres;

--
-- Name: user_comment_dislikes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_comment_dislikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_comment_dislikes_id_seq OWNER TO postgres;

--
-- Name: user_comment_dislikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_comment_dislikes_id_seq OWNED BY public.user_comment_dislikes.id;


--
-- Name: user_comment_likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_comment_likes (
    id integer NOT NULL,
    idea_comment_id integer,
    author_id text
);


ALTER TABLE public.user_comment_likes OWNER TO postgres;

--
-- Name: user_comment_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_comment_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_comment_likes_id_seq OWNER TO postgres;

--
-- Name: user_comment_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_comment_likes_id_seq OWNED BY public.user_comment_likes.id;


--
-- Name: user_geo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_geo (
    id integer NOT NULL,
    user_id text NOT NULL,
    lat numeric(65,30),
    lon numeric(65,30),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    work_lat numeric(65,30),
    work_lon numeric(65,30),
    school_lat numeric(65,30),
    school_lon numeric(65,30)
);


ALTER TABLE public.user_geo OWNER TO postgres;

--
-- Name: user_geo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_geo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_geo_id_seq OWNER TO postgres;

--
-- Name: user_geo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_geo_id_seq OWNED BY public.user_geo.id;


--
-- Name: advertisement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisement ALTER COLUMN id SET DEFAULT nextval('public.advertisement_id_seq'::regclass);


--
-- Name: category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category ALTER COLUMN id SET DEFAULT nextval('public.category_id_seq'::regclass);


--
-- Name: idea id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea ALTER COLUMN id SET DEFAULT nextval('public.idea_id_seq'::regclass);


--
-- Name: idea_address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_address ALTER COLUMN id SET DEFAULT nextval('public.idea_address_id_seq'::regclass);


--
-- Name: idea_comment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_comment ALTER COLUMN id SET DEFAULT nextval('public.idea_comment_id_seq'::regclass);


--
-- Name: idea_geo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_geo ALTER COLUMN id SET DEFAULT nextval('public.idea_geo_id_seq'::regclass);


--
-- Name: idea_rating id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_rating ALTER COLUMN id SET DEFAULT nextval('public.idea_rating_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: proposal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposal ALTER COLUMN id SET DEFAULT nextval('public.proposal_id_seq'::regclass);


--
-- Name: report id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report ALTER COLUMN id SET DEFAULT nextval('public.report_id_seq'::regclass);


--
-- Name: segment seg_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segment ALTER COLUMN seg_id SET DEFAULT nextval('public.segment_seg_id_seq'::regclass);


--
-- Name: segmentRequest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."segmentRequest" ALTER COLUMN id SET DEFAULT nextval('public."segmentRequest_id_seq"'::regclass);


--
-- Name: sub_segment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_segment ALTER COLUMN id SET DEFAULT nextval('public.sub_segment_id_seq'::regclass);


--
-- Name: super_segment super_seg_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_segment ALTER COLUMN super_seg_id SET DEFAULT nextval('public.super_segment_super_seg_id_seq'::regclass);


--
-- Name: user_address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_address ALTER COLUMN id SET DEFAULT nextval('public.user_address_id_seq'::regclass);


--
-- Name: user_comment_dislikes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_dislikes ALTER COLUMN id SET DEFAULT nextval('public.user_comment_dislikes_id_seq'::regclass);


--
-- Name: user_comment_likes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_likes ALTER COLUMN id SET DEFAULT nextval('public.user_comment_likes_id_seq'::regclass);


--
-- Name: user_geo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_geo ALTER COLUMN id SET DEFAULT nextval('public.user_geo_id_seq'::regclass);


--
-- Data for Name: UserSegments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserSegments" (id, user_id, home_segment_id, work_segment_id, school_segment_id, home_sub_segment, work_sub_segment, school_sub_segment, home_segment_name, work_segment_name, school_segment_name, home_sub_segment_name, work_sub_segment_name, school_sub_segment_name, home_super_segment_id, home_super_segment_name, work_super_segment_id, work_super_segment_name, school_super_segment_id, school_super_segment_name) FROM stdin;
\.
COPY public."UserSegments" (id, user_id, home_segment_id, work_segment_id, school_segment_id, home_sub_segment, work_sub_segment, school_sub_segment, home_segment_name, work_segment_name, school_segment_name, home_sub_segment_name, work_sub_segment_name, school_sub_segment_name, home_super_segment_id, home_super_segment_name, work_super_segment_id, work_super_segment_name, school_super_segment_id, school_super_segment_name) FROM '$$PATH$$/3186.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3152.dat';

--
-- Data for Name: advertisement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertisement (id, owner_id, creat_at, update_at, advertisement_title, advertisement_type, advertisement_duration, advertisement_position, advertisement_image_path, advertisement_external_link, published) FROM stdin;
\.
COPY public.advertisement (id, owner_id, creat_at, update_at, advertisement_title, advertisement_type, advertisement_duration, advertisement_position, advertisement_image_path, advertisement_external_link, published) FROM '$$PATH$$/3181.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (id, title, description, created_at, updated_at) FROM stdin;
\.
COPY public.category (id, title, description, created_at, updated_at) FROM '$$PATH$$/3161.dat';

--
-- Data for Name: idea; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idea (id, author_id, category_id, title, description, community_impact, nature_impact, arts_impact, energy_impact, manufacturing_impact, state, active, created_at, updated_at, champion_id, segment_id, sub_segment_id, "userType", image_path, super_segment_id) FROM stdin;
\.
COPY public.idea (id, author_id, category_id, title, description, community_impact, nature_impact, arts_impact, energy_impact, manufacturing_impact, state, active, created_at, updated_at, champion_id, segment_id, sub_segment_id, "userType", image_path, super_segment_id) FROM '$$PATH$$/3167.dat';

--
-- Data for Name: idea_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idea_address (id, idea_id, street_address, street_address_2, city, country, postal_code, created_at, updated_at) FROM stdin;
\.
COPY public.idea_address (id, idea_id, street_address, street_address_2, city, country, postal_code, created_at, updated_at) FROM '$$PATH$$/3165.dat';

--
-- Data for Name: idea_comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idea_comment (id, idea_id, author_id, content, active, created_at, updated_at, user_segment_id, segment_id, super_segment_id, sub_segment_id) FROM stdin;
\.
COPY public.idea_comment (id, idea_id, author_id, content, active, created_at, updated_at, user_segment_id, segment_id, super_segment_id, sub_segment_id) FROM '$$PATH$$/3175.dat';

--
-- Data for Name: idea_geo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idea_geo (id, idea_id, lat, lon, created_at, updated_at) FROM stdin;
\.
COPY public.idea_geo (id, idea_id, lat, lon, created_at, updated_at) FROM '$$PATH$$/3163.dat';

--
-- Data for Name: idea_rating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idea_rating (id, idea_id, author_id, rating, rating_explanation, created_at, updated_at) FROM stdin;
\.
COPY public.idea_rating (id, idea_id, author_id, rating, rating_explanation, created_at, updated_at) FROM '$$PATH$$/3173.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, idea_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.project (id, idea_id, description, created_at, updated_at) FROM '$$PATH$$/3171.dat';

--
-- Data for Name: proposal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proposal (id, idea_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.proposal (id, idea_id, description, created_at, updated_at) FROM '$$PATH$$/3169.dat';

--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report (id, email, description, created_at, updated_at) FROM stdin;
\.
COPY public.report (id, email, description, created_at, updated_at) FROM '$$PATH$$/3154.dat';

--
-- Data for Name: segment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.segment (seg_id, country, province, segment_name, super_segment_name, created_at, update_at, "superSegId") FROM stdin;
\.
COPY public.segment (seg_id, country, province, segment_name, super_segment_name, created_at, update_at, "superSegId") FROM '$$PATH$$/3183.dat';

--
-- Data for Name: segmentRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."segmentRequest" (id, created_at, user_id, country, province, "segment name", "sub segment name") FROM stdin;
\.
COPY public."segmentRequest" (id, created_at, user_id, country, province, "segment name", "sub segment name") FROM '$$PATH$$/3188.dat';

--
-- Data for Name: sub_segment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_segment (id, seg_id, sub_segment_name, lat, lon, created_at, update_at) FROM stdin;
\.
COPY public.sub_segment (id, seg_id, sub_segment_name, lat, lon, created_at, update_at) FROM '$$PATH$$/3185.dat';

--
-- Data for Name: super_segment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_segment (super_seg_id, name, country, province, created_at, updated_at) FROM stdin;
\.
COPY public.super_segment (super_seg_id, name, country, province, created_at, updated_at) FROM '$$PATH$$/3190.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, user_type, email, password, f_name, l_name, created_at, updated_at, "passCode", "imagePath", banned) FROM stdin;
\.
COPY public."user" (id, user_type, email, password, f_name, l_name, created_at, updated_at, "passCode", "imagePath", banned) FROM '$$PATH$$/3159.dat';

--
-- Data for Name: user_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_address (id, user_id, street_address, street_address_2, city, country, postal_code, created_at, updated_at) FROM stdin;
\.
COPY public.user_address (id, user_id, street_address, street_address_2, city, country, postal_code, created_at, updated_at) FROM '$$PATH$$/3158.dat';

--
-- Data for Name: user_comment_dislikes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_comment_dislikes (id, idea_comment_id, author_id) FROM stdin;
\.
COPY public.user_comment_dislikes (id, idea_comment_id, author_id) FROM '$$PATH$$/3179.dat';

--
-- Data for Name: user_comment_likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_comment_likes (id, idea_comment_id, author_id) FROM stdin;
\.
COPY public.user_comment_likes (id, idea_comment_id, author_id) FROM '$$PATH$$/3177.dat';

--
-- Data for Name: user_geo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_geo (id, user_id, lat, lon, created_at, updated_at, work_lat, work_lon, school_lat, school_lon) FROM stdin;
\.
COPY public.user_geo (id, user_id, lat, lon, created_at, updated_at, work_lat, work_lon, school_lat, school_lon) FROM '$$PATH$$/3156.dat';

--
-- Name: advertisement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertisement_id_seq', 1, false);


--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_id_seq', 8, true);


--
-- Name: idea_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.idea_address_id_seq', 4, true);


--
-- Name: idea_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.idea_comment_id_seq', 10, true);


--
-- Name: idea_geo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.idea_geo_id_seq', 4, true);


--
-- Name: idea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.idea_id_seq', 4, true);


--
-- Name: idea_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.idea_rating_id_seq', 11, true);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_id_seq', 1, false);


--
-- Name: proposal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proposal_id_seq', 1, false);


--
-- Name: report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_id_seq', 1, false);


--
-- Name: segmentRequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."segmentRequest_id_seq"', 1, true);


--
-- Name: segment_seg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.segment_seg_id_seq', 3, true);


--
-- Name: sub_segment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sub_segment_id_seq', 4, true);


--
-- Name: super_segment_super_seg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.super_segment_super_seg_id_seq', 1, true);


--
-- Name: user_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_address_id_seq', 7, true);


--
-- Name: user_comment_dislikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_comment_dislikes_id_seq', 6, true);


--
-- Name: user_comment_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_comment_likes_id_seq', 20, true);


--
-- Name: user_geo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_geo_id_seq', 7, true);


--
-- Name: UserSegments UserSegments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: advertisement advertisement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisement
    ADD CONSTRAINT advertisement_pkey PRIMARY KEY (id);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: idea_address idea_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_address
    ADD CONSTRAINT idea_address_pkey PRIMARY KEY (id);


--
-- Name: idea_comment idea_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_comment
    ADD CONSTRAINT idea_comment_pkey PRIMARY KEY (id);


--
-- Name: idea_geo idea_geo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_geo
    ADD CONSTRAINT idea_geo_pkey PRIMARY KEY (id);


--
-- Name: idea idea_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_pkey PRIMARY KEY (id);


--
-- Name: idea_rating idea_rating_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_rating
    ADD CONSTRAINT idea_rating_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: proposal proposal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT proposal_pkey PRIMARY KEY (id);


--
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (id);


--
-- Name: segmentRequest segmentRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."segmentRequest"
    ADD CONSTRAINT "segmentRequest_pkey" PRIMARY KEY (id);


--
-- Name: segment segment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segment
    ADD CONSTRAINT segment_pkey PRIMARY KEY (seg_id);


--
-- Name: sub_segment sub_segment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_segment
    ADD CONSTRAINT sub_segment_pkey PRIMARY KEY (id);


--
-- Name: super_segment super_segment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_segment
    ADD CONSTRAINT super_segment_pkey PRIMARY KEY (super_seg_id);


--
-- Name: user_address user_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_address
    ADD CONSTRAINT user_address_pkey PRIMARY KEY (id);


--
-- Name: user_comment_dislikes user_comment_dislikes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_dislikes
    ADD CONSTRAINT user_comment_dislikes_pkey PRIMARY KEY (id);


--
-- Name: user_comment_likes user_comment_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_likes
    ADD CONSTRAINT user_comment_likes_pkey PRIMARY KEY (id);


--
-- Name: user_geo user_geo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_geo
    ADD CONSTRAINT user_geo_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: UserSegments_user_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UserSegments_user_id_unique" ON public."UserSegments" USING btree (user_id);


--
-- Name: category.title_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "category.title_unique" ON public.category USING btree (title);


--
-- Name: idea_address_idea_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idea_address_idea_id_unique ON public.idea_address USING btree (idea_id);


--
-- Name: idea_geo_idea_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idea_geo_idea_id_unique ON public.idea_geo USING btree (idea_id);


--
-- Name: project_idea_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX project_idea_id_unique ON public.project USING btree (idea_id);


--
-- Name: proposal_idea_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX proposal_idea_id_unique ON public.proposal USING btree (idea_id);


--
-- Name: user.email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user.email_unique" ON public."user" USING btree (email);


--
-- Name: user_address_user_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_address_user_id_unique ON public.user_address USING btree (user_id);


--
-- Name: user_geo_user_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_geo_user_id_unique ON public.user_geo USING btree (user_id);


--
-- Name: UserSegments UserSegments_home_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_home_segment_id_fkey" FOREIGN KEY (home_segment_id) REFERENCES public.segment(seg_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_home_sub_segment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_home_sub_segment_fkey" FOREIGN KEY (home_sub_segment) REFERENCES public.sub_segment(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_home_super_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_home_super_segment_id_fkey" FOREIGN KEY (home_super_segment_id) REFERENCES public.super_segment(super_seg_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_school_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_school_segment_id_fkey" FOREIGN KEY (school_segment_id) REFERENCES public.segment(seg_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_school_sub_segment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_school_sub_segment_fkey" FOREIGN KEY (school_sub_segment) REFERENCES public.sub_segment(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_school_super_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_school_super_segment_id_fkey" FOREIGN KEY (school_super_segment_id) REFERENCES public.super_segment(super_seg_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserSegments UserSegments_work_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_work_segment_id_fkey" FOREIGN KEY (work_segment_id) REFERENCES public.segment(seg_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_work_sub_segment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_work_sub_segment_fkey" FOREIGN KEY (work_sub_segment) REFERENCES public.sub_segment(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserSegments UserSegments_work_super_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserSegments"
    ADD CONSTRAINT "UserSegments_work_super_segment_id_fkey" FOREIGN KEY (work_super_segment_id) REFERENCES public.super_segment(super_seg_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: advertisement advertisement_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisement
    ADD CONSTRAINT advertisement_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: idea_address idea_address_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_address
    ADD CONSTRAINT idea_address_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea idea_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_author_id_fkey FOREIGN KEY (author_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea idea_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea idea_champion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_champion_id_fkey FOREIGN KEY (champion_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: idea_comment idea_comment_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_comment
    ADD CONSTRAINT idea_comment_author_id_fkey FOREIGN KEY (author_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea_comment idea_comment_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_comment
    ADD CONSTRAINT idea_comment_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea_comment idea_comment_user_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_comment
    ADD CONSTRAINT idea_comment_user_segment_id_fkey FOREIGN KEY (user_segment_id) REFERENCES public."UserSegments"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea_geo idea_geo_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_geo
    ADD CONSTRAINT idea_geo_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea_rating idea_rating_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_rating
    ADD CONSTRAINT idea_rating_author_id_fkey FOREIGN KEY (author_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea_rating idea_rating_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea_rating
    ADD CONSTRAINT idea_rating_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea idea_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segment(seg_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea idea_sub_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_sub_segment_id_fkey FOREIGN KEY (sub_segment_id) REFERENCES public.sub_segment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idea idea_super_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_super_segment_id_fkey FOREIGN KEY (super_segment_id) REFERENCES public.super_segment(super_seg_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project project_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: proposal proposal_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT proposal_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: segmentRequest segmentRequest_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."segmentRequest"
    ADD CONSTRAINT "segmentRequest_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: segment segment_superSegId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segment
    ADD CONSTRAINT "segment_superSegId_fkey" FOREIGN KEY ("superSegId") REFERENCES public.super_segment(super_seg_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sub_segment sub_segment_seg_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_segment
    ADD CONSTRAINT sub_segment_seg_id_fkey FOREIGN KEY (seg_id) REFERENCES public.segment(seg_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_address user_address_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_address
    ADD CONSTRAINT user_address_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_comment_dislikes user_comment_dislikes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_dislikes
    ADD CONSTRAINT user_comment_dislikes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_comment_dislikes user_comment_dislikes_idea_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_dislikes
    ADD CONSTRAINT user_comment_dislikes_idea_comment_id_fkey FOREIGN KEY (idea_comment_id) REFERENCES public.idea_comment(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_comment_likes user_comment_likes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_likes
    ADD CONSTRAINT user_comment_likes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_comment_likes user_comment_likes_idea_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_comment_likes
    ADD CONSTRAINT user_comment_likes_idea_comment_id_fkey FOREIGN KEY (idea_comment_id) REFERENCES public.idea_comment(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_geo user_geo_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_geo
    ADD CONSTRAINT user_geo_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

